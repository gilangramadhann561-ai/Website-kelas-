const menuBtn=document.getElementById("menuBtn"),nav=document.getElementById("navLinks");
menuBtn.onclick=()=>nav.classList.toggle("active");
document.querySelectorAll(".nav-links a").forEach(a=>a.onclick=()=>nav.classList.remove("active"));

const slides=document.querySelectorAll(".hero-slide"),dots=document.getElementById("dots");
let current=0;
slides.forEach((_,i)=>{const b=document.createElement("button");b.onclick=()=>showSlide(i);dots.appendChild(b)});
function showSlide(i){current=i;slides.forEach((s,n)=>s.classList.toggle("active",n===i));[...dots.children].forEach((b,n)=>b.classList.toggle("active",n===i))}
showSlide(0);setInterval(()=>showSlide((current+1)%slides.length),5000);

const themeBtn=document.getElementById("themeBtn");
themeBtn.onclick=()=>{document.body.classList.toggle("dark");themeBtn.textContent=document.body.classList.contains("dark")?"☀️":"🌙";localStorage.setItem("dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("dark")==="true"){document.body.classList.add("dark");themeBtn.textContent="☀️"}

const lb=document.getElementById("lightbox"),lbImg=document.getElementById("lightboxImg");
document.querySelectorAll(".gallery img").forEach(img=>img.onclick=()=>{lbImg.src=img.src;lb.classList.add("show")});
document.getElementById("closeLightbox").onclick=()=>lb.classList.remove("show");
lb.onclick=e=>{if(e.target===lb)lb.classList.remove("show")};

document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("contactForm").onsubmit=e=>{e.preventDefault();alert("Pesan berhasil disiapkan. Hubungkan form ke backend/Formspree agar pesan benar-benar masuk.");e.target.reset()};
document.getElementById("waFloat").onclick=()=>window.open("https://wa.me/6281234567890","_blank");
