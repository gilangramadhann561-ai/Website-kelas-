WEBSITE SEKOLAH V2

FILE:
index.html = isi website
style.css = tampilan
script.js = slider, dark mode, galeri, menu, dll
assets/ = semua foto/logo

GANTI FOTO:
hero1.jpg hero2.jpg hero3.jpg = foto banner utama
sekolah.jpg = gedung sekolah
berita1.jpg sampai berita3.jpg = berita
galeri1.jpg sampai galeri6.jpg = galeri
logo.png = logo

GANTI NAMA:
Cari "SMK NUSANTARA" di index.html.

GANTI NOMOR WHATSAPP:
Cari 6281234567890 di index.html dan script.js lalu ganti dengan nomor sekolah.

GANTI ALAMAT/MAP:
Edit alamat dan URL iframe Google Maps di index.html.

GANTI WARNA:
Edit --blue dan --navy di bagian :root pada style.css.

ONLINE:
Upload folder ini ke GitHub Pages, Netlify, atau Vercel.
